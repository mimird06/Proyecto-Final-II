﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capa_Entidades
{
    public class E_Users
    {
        //Declaracion de variables para recibir y enviar datos
        public String usuario { get; set; }

        public String clave { get; set; }
    }
}
